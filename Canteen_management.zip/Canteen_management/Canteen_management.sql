CREATE DATABASE MyDatabase;
USE MyDatabase;

CREATE TABLE ItemsTbl(
	ItemId int PRIMARY KEY AUTO_INCREMENT,
	ItemName varchar(30),
	Category VARCHAR(40),
	Price INT
);

CREATE TABLE Bills(
	BNum INT PRIMARY KEY AUTO_INCREMENT, 
	StudentName VARCHAR(40), 
	BDate VARCHAR(30), 
	totalAmount DOUBLE
);


CREATE TABLE BillDetails(
	ItemId INT PRIMARY KEY AUTO_INCREMENT, 
	ItemName VARCHAR(30), 
	Price DOUBLE, 
	Qty INT);
